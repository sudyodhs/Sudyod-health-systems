# Sudyod สุดยอด — Herb Basics NZ Website

## Deploy to Vercel in 10 minutes

### Step 1 — Get a free GitHub account (if you don't have one)
Go to github.com and sign up. Free.

### Step 2 — Create a new GitHub repository
1. Go to github.com/new
2. Name it: `sudyod-herbbasics`
3. Set it to Private
4. Click "Create repository"

### Step 3 — Upload these files to GitHub
GitHub will show you instructions after creating the repo. The simplest way:
1. Click "uploading an existing file" on the GitHub page
2. Drag ALL files and folders from this zip into the upload area
3. Click "Commit changes"

### Step 4 — Deploy to Vercel
1. Go to vercel.com and sign up with your GitHub account (free)
2. Click "Add New Project"
3. Select your `sudyod-herbbasics` repository
4. Vercel will auto-detect it as a Vite project
5. Click "Deploy"
6. Your site will be live at: `sudyod-herbbasics.vercel.app` within 2 minutes

### Step 5 — Add your custom domain (sudyod.co.nz)
1. In Vercel dashboard → your project → Settings → Domains
2. Add: `sudyod.co.nz` and `www.sudyod.co.nz`
3. Vercel will give you DNS records to add to your domain registrar
4. Done — your site is live at sudyod.co.nz

### Step 6 — Link to your Squarespace shop
In the website file (src/App.jsx), find all instances of:
  "Shop Now", "Shop the Collection", "Add" buttons

Update each button's onClick to link to your Squarespace store URL, e.g.:
  window.open('https://your-store.squarespace.com/shop', '_blank')

Or add a Squarespace "Buy Button" widget by pasting their embed code into
the index.html file inside the <body> tag.

---

## File structure
```
sudyod-site/
├── index.html          ← Main HTML entry point
├── vite.config.js      ← Build configuration
├── vercel.json         ← Vercel deployment config
├── package.json        ← Dependencies
├── public/
│   └── favicon.svg     ← Sudyod peak mark favicon
└── src/
    ├── main.jsx        ← React entry point
    └── App.jsx         ← Full website (edit content here)
```

## Editing content
All website content is in `src/App.jsx`. Key sections to update:
- Product names and prices — search for `const products = [`
- Collection descriptions — search for `const collections = [`
- Your Squarespace store URL — search for `Shop Now` buttons
- Contact details in the footer

## Adding the Kiri AI chat widget
Once your Claude API backend is set up:
1. You'll receive a JavaScript embed snippet
2. Paste it into index.html inside the <head> tag
3. The floating 🌿 chat button will connect to the live Claude backend

---
Sudyod Health Systems Ltd · 3 Plimsoll St, Carterton 5713, NZ
Official NZ Importer — Herb Basics, Chiang Mai
